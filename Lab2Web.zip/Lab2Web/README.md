# Lab2Web — Praktikum 2: HTML Lanjutan

Pemrograman Web — Universitas Pelita Bangsa

**Nama:** _(isi nama)_  
**NIM:** _(isi NIM)_  
**Kelas:** _(isi kelas)_

## Struktur Folder

```
Lab2Web/
├── index.html      # Latihan langkah 1–8
├── biodata.html    # Proyek mini (langkah 9)
├── media/
│   ├── audio.mp3
│   └── video.mp4
├── screenshots/    # Screenshot hasil praktik
└── README.md
```

## Langkah Praktikum

### 1. Tabel Data Mahasiswa
Membuat tabel dengan `<table>`, `<tr>`, `<th>`, `<td>` dan minimal tiga data mahasiswa.

![Tabel](screenshots/01-tabel.png)

### 2. Tabel dengan thead, tbody, tfoot
Menambahkan `<caption>`, `<thead>`, `<tbody>`, `<tfoot>`, serta `colspan` untuk menggabungkan sel.

![Tabel terstruktur](screenshots/02-tabel-terstruktur.png)

### 3. Form Registrasi Mahasiswa
Form dengan input `text`, `email`, `password`, `date`, `file`, serta tombol `submit` dan `reset`.

![Form registrasi](screenshots/03-form-registrasi.png)

### 4. Radio Button dan Checkbox
Radio (`name` sama → hanya satu pilihan) dan checkbox (boleh lebih dari satu).

![Radio dan checkbox](screenshots/04-radio-checkbox.png)

### 5. Select dan Textarea
Dropdown program studi dan area teks alamat.

![Select dan textarea](screenshots/05-select-textarea.png)

### 6. Validasi Form Dasar
Atribut `required`, `minlength`, `maxlength`, `min`, `max`, `type`, dan `pattern`.

![Validasi](screenshots/06-validasi.png)

### 7. Semantic HTML
Menggunakan `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`, `<footer>`.

![Semantic](screenshots/07-semantic.png)

### 8. Multimedia
Elemen `<audio>` dan `<video>` dengan file di folder `media/`.

![Multimedia](screenshots/08-multimedia.png)

### 9. Proyek Mini — Biodata Mahasiswa
`biodata.html` menggabungkan semantic structure, tabel, form, validasi dasar, dan video.

![Biodata](screenshots/09-biodata.png)

## Jawaban Pertanyaan

1. **Fungsi `<table>`, `<tr>`, `<th>`, `<td>`:** `<table>` membuat tabel, `<tr>` membuat baris, `<th>` membuat sel header, `<td>` membuat sel data.
2. **Beda `<th>` dan `<td>`:** `<th>` adalah sel judul kolom/baris (tebal dan rata tengah secara default, bermakna header untuk screen reader), sedangkan `<td>` adalah sel data biasa.
3. **`colspan`:** menggabungkan beberapa kolom menjadi satu sel secara horizontal.
4. **`<form>`:** mengelompokkan elemen input untuk mengumpulkan data pengguna dan mengirimkannya (ke server) saat disubmit.
5. **Radio vs checkbox:** radio dengan `name` yang sama hanya membolehkan satu pilihan; checkbox membolehkan satu, beberapa, atau tidak ada pilihan.
6. **`<label for>` terhubung ke `id`:** klik pada label otomatis memfokuskan/memilih input (area klik lebih luas) dan membantu aksesibilitas karena screen reader membacakan label input.
7. **`<textarea>` vs `input type="text"`:** `<textarea>` untuk teks multibaris/panjang (atur `rows` dan `cols`), sedangkan `input type="text"` hanya satu baris.
8. **Semantic HTML:** memberi makna pada struktur halaman — `<header>` kepala, `<nav>` navigasi, `<main>` konten utama, `<section>` kelompok konten, `<article>` konten mandiri, `<aside>` konten pelengkap, `<footer>` kaki halaman. Manfaatnya: kode lebih mudah dibaca, aksesibel, dan ramah SEO.
9. **Atribut validasi:** `required` wajib diisi, `min`/`max` batas nilai angka/tanggal, `minlength` panjang minimum teks.
10. **`<audio>` vs `<video>`:** `<audio>` untuk suara saja (tanpa tampilan visual); `<video>` untuk gambar bergerak beserta suara dan mendukung `width`/`height`/`poster`.

## Cara Menjalankan

Buka `index.html` atau `biodata.html` di browser (klik dua kali, atau gunakan ekstensi Live Server di VS Code).

## Catatan

File `media/audio.mp3` dan `media/video.mp4` adalah contoh (nada sederhana dan video berwarna). Silakan ganti dengan media milik sendiri dengan nama file yang sama.
